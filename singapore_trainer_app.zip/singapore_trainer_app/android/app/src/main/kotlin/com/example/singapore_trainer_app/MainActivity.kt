package com.example.singapore_trainer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
