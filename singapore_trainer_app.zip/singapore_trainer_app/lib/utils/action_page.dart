import 'package:flutter/material.dart';

class AdminActionsPage extends StatefulWidget {
  @override
  _AdminActionsPageState createState() => _AdminActionsPageState();
}

class _AdminActionsPageState extends State<AdminActionsPage> {
  final List<User> users = [
    User(name: 'John Doe', role: 'Trainer'),
    User(name: 'Jane Smith', role: 'Learner'),
    User(name: 'Michael Johnson', role: 'Trainer'),
    User(name: 'Emily Davis', role: 'Learner'),
  ];

  User? selectedUser;
  String? selectedAction;
  final TextEditingController reasonController = TextEditingController();

  final List<String> actions = ['Warn', 'Suspend', 'Remove'];

  void submitAction() {
    if (selectedUser == null || selectedAction == null || reasonController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please complete all fields')),
      );
      return;
    }

    // Handle action submission (e.g., send data to a server or database)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${selectedAction} action taken against ${selectedUser!.name} (${selectedUser!.role}) for reason: ${reasonController.text}',
        ),
      ),
    );

    // Clear the form
    setState(() {
      selectedUser = null;
      selectedAction = null;
      reasonController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        iconTheme: IconThemeData(color: Colors.white),
        title: Text(
          'ADMIN ACTIONS',
          style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18, color: Colors.white),
        ),
        backgroundColor: Color(0xFF659F62), // Dark Green theme color
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Select User',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF659F62)),
                ),
                DropdownButton<User>(
                  isExpanded: true,
                  hint: Text('Choose a user'),
                  value: selectedUser,
                  onChanged: (User? newValue) {
                    setState(() {
                      selectedUser = newValue;
                    });
                  },
                  items: users.map<DropdownMenuItem<User>>((User user) {
                    return DropdownMenuItem<User>(
                      value: user,
                      child: Text('${user.name} (${user.role})'),
                    );
                  }).toList(),
                ),
                SizedBox(height: 20),
                Text(
                  'Select Action',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF659F62)),
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  hint: Text('Choose an action'),
                  value: selectedAction,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedAction = newValue;
                    });
                  },
                  items: actions.map<DropdownMenuItem<String>>((String action) {
                    return DropdownMenuItem<String>(
                      value: action,
                      child: Text(action),
                    );
                  }).toList(),
                ),
                SizedBox(height: 20),
                Text(
                  'Reason',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF659F62)),
                ),
                TextField(
                  controller: reasonController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintText: 'Enter the reason for this action',
                  ),
                  maxLines: 3,
                ),
                SizedBox(height: 20),
                Center(
                  child: ElevatedButton(
                    onPressed: submitAction,
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      backgroundColor: Color(0xFF659F62),
                    ),
                    child: Text(
                      'Submit Action',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class User {
  final String name;
  final String role;

  User({required this.name, required this.role});
}
