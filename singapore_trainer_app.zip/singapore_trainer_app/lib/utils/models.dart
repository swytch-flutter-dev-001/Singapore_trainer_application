// // class Insight {
// //   final String title;
// //   final String description;
// //   final double progress;
// //   final Map<String, int> metrics; // e.g., {"Speed": 80, "Endurance": 75}
// //
// //   Insight({required this.title, required this.description, required this.progress, required this.metrics});
// // }
// class Trainer {
//   final String name;
//   final String category;
//   final String place;
//   final String date;
//   final String time;
//   String status; // "Pending", "Accepted", or "Rejected"
//
//   Trainer({
//     required this.name,
//     required this.category,
//     required this.place,
//     required this.date,
//     required this.time,
//     this.status = "Pending",
//   });
// }
