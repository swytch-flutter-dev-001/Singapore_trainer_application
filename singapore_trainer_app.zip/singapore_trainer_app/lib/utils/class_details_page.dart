import 'package:flutter/material.dart';

class ClassDetailPage extends StatefulWidget {
  final Map<String, String> classInfo;

  const ClassDetailPage({Key? key, required this.classInfo}) : super(key: key);

  @override
  _ClassDetailPageState createState() => _ClassDetailPageState();
}

class _ClassDetailPageState extends State<ClassDetailPage> {
  bool isJoined = false; // To track whether the class is joined

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFF659F62),
        title: Text(
          widget.classInfo['className'] ?? 'Class',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Class Info Section
            _buildClassInfo(),
            const SizedBox(height: 20),
            // Trainer Info Section
            _buildTrainerInfo(),
            const SizedBox(height: 20),
            // Action Button (Join or Leave)
            _buildActionButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildClassInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Class Information",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                widget.classInfo['imageUrl'] ?? 'https://via.placeholder.com/80',
                width: 100,
                height: 100,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Icon(Icons.broken_image, size: 100),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.classInfo['className'] ?? 'Class',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
                  ),
                  const SizedBox(height: 10),
                  Text("Time: ${widget.classInfo['time'] ?? 'N/A'}"),
                  const SizedBox(height: 5),
                  Text("Trainer: ${widget.classInfo['trainerName'] ?? 'Unknown'}"),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTrainerInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Trainer Information",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                widget.classInfo['trainerImage'] ?? 'https://via.placeholder.com/80',
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Icon(Icons.broken_image, size: 80),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.classInfo['trainerName'] ?? 'Trainer',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(widget.classInfo['trainerBio'] ?? 'No bio available'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // Action Button to Join or Leave Class
  Widget _buildActionButton(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: () {
          if (!isJoined) {
            // Join the class
            setState(() {
              isJoined = true;
            });
            // Show SnackBar when joining the class
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('You have joined the class!'),
                duration: const Duration(seconds: 2),
              ),
            );
          } else {
            // Leave the class
            setState(() {
              isJoined = false;
            });
            // Show SnackBar when leaving the class
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text('You have left the class!'),
                duration: const Duration(seconds: 2),
              ),
            );
            // Navigate back to the previous page after leaving
            Navigator.pop(context);
          }
        },
        child: Text(isJoined ? 'Leave Class' : 'Join Class'),
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          backgroundColor: isJoined ? Colors.red : const Color(0xFF659F62), // Red if leaving, Green if joining
          foregroundColor: Colors.white,
        ),
      ),
    );
  }
}
