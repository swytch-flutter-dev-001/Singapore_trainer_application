import 'package:flashy_tab_bar2/flashy_tab_bar2.dart';
import 'package:flutter/material.dart';
import 'package:singapore_trainer_app/Trainer_screens/trainer_home.dart';
import 'package:singapore_trainer_app/screens/admin_screens/admin_home.dart';

import 'Learner_calenders.dart';
import 'Learner_class_details.dart';
import 'Learner_profile.dart';
import 'Lerner_notifications.dart';
import 'learner_chating.dart';
import 'learner_time_management.dart';
import 'leraner_dashboard.dart';

class Learner_home extends StatefulWidget {
  const Learner_home({super.key});

  @override
  State<Learner_home> createState() => _Learner_homeState();
}

class _Learner_homeState extends State<Learner_home> {
  int selectedIndex = 0;
  final PageController _pageController = PageController();

  final List<Widget> tabs = [
    LearnerServicePage(),
    ChatingLearner(),
    LernerCalendarPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: selectedIndex == 0
          ? AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        backgroundColor: const Color(0xFF659F62),
        toolbarHeight: 80,
        title: const Text(
          "LEARNER HOME",
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 18,
            color: Colors.white,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LearnerNotificationPage(),
                  ),
                );
              },
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              ),
            ),
          ),
        ],
      )
          : null,
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          children: [
            const SizedBox(height: 20),
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF659F62)),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const learner_profile(),
                        ),
                      );
                    },
                    child: const CircleAvatar(
                      radius: 40,
                      backgroundImage: AssetImage('assets/profile.jpg'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "LEARNER MENU",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text("Dashboard"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LearnerDashboard(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text("Dashboard"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TimeManagementPage(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text("Trainer"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Trainer_home(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text("Admin"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AdminHome(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        children: tabs,
      ),
      bottomNavigationBar: FlashyTabBar(
        selectedIndex: selectedIndex,
        backgroundColor: Colors.white,
        iconSize: 30,
        animationCurve: Curves.easeInOut,
        animationDuration: const Duration(milliseconds: 300),
        onItemSelected: (index) {
          setState(() {
            selectedIndex = index;
            _pageController.animateToPage(
              index,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          });
        },
        items: [
          FlashyTabBarItem(
            icon: const Icon(Icons.person_search),
            title: const Text('Home'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
          FlashyTabBarItem(
            icon: const Icon(Icons.chat),
            title: const Text('Chat'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
          FlashyTabBarItem(
            icon: const Icon(Icons.calendar_month),
            title: const Text('Calendar'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
        ],
      ),
    );
  }
}
