import 'package:flutter/material.dart';

class ChatingLearner extends StatefulWidget {
  const ChatingLearner({super.key});

  @override
  State<ChatingLearner> createState() => _ChatingLearnerState();
}

class _ChatingLearnerState extends State<ChatingLearner> {
  final List<Map<String, String>> _messages = [];
  final TextEditingController _messageController = TextEditingController();

  // Colors
  final Color primaryColor = const Color(0xFF659F62);
  final Color secondaryColor = const Color(0xFF92C287);
  final Color backgroundColor = const Color(0xFFF0F8F5);

  // Dropdown for selecting recipient
  String _selectedRecipient = "ADMIN";
  final List<String> _recipients = ["ADMIN", "TRAINER"];

  // Send message function
  void _sendMessage() {
    if (_messageController.text.trim().isNotEmpty) {
      setState(() {
        _messages.add({
          "sender": "Learner",
          "recipient": _selectedRecipient,
          "text": _messageController.text.trim(),
        });
      });
      _messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        toolbarHeight: 80,
        iconTheme: IconThemeData(
          color: Colors.white
        ),
        title: Text("CHAT WITH $_selectedRecipient",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w500,fontSize: 18),),
        backgroundColor: primaryColor,
        actions: [
          // Dropdown to select recipient (Admin or Trainer)
          DropdownButton<String>(
            value: _selectedRecipient,
            dropdownColor: Colors.white,
            icon: Icon(Icons.arrow_drop_down, color: Colors.white),
            onChanged: (String? newValue) {
              setState(() {
                _selectedRecipient = newValue!;
              });
            },
            items: _recipients.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: TextStyle(color: Colors.white)),
              );
            }).toList(),
          ),
          SizedBox(width: 10),
        ],
      ),
      body: Column(
        children: [
          // Chat messages
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              padding: const EdgeInsets.symmetric(vertical: 10),
              itemBuilder: (context, index) {
                final message = _messages[index];
                final isMe = message['sender'] == "Learner";

                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isMe ? primaryColor : secondaryColor,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(isMe ? 12 : 0),
                        topRight: Radius.circular(isMe ? 0 : 12),
                        bottomLeft: const Radius.circular(12),
                        bottomRight: const Radius.circular(12),
                      ),
                    ),
                    child: Text(
                      message['text'] ?? '',
                      style: TextStyle(
                        fontSize: 14,
                        color: isMe ? Colors.white : Colors.black,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Input area
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Type a service-related message...',
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  radius: 22,
                  backgroundColor: primaryColor,
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
