import 'package:flutter/material.dart';

class AdminAddNotification extends StatefulWidget {
  const AdminAddNotification({super.key});

  @override
  State<AdminAddNotification> createState() => _AdminAddNotificationState();
}

class _AdminAddNotificationState extends State<AdminAddNotification> {
  final matterCtrl = TextEditingController();
  final contentCtrl = TextEditingController();

  @override
  void dispose() {
    matterCtrl.dispose();
    contentCtrl.dispose();
    super.dispose();
  }

  void clearFields() {
    matterCtrl.clear();
    contentCtrl.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Notification added successfully!"),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF92C287), // Medium Green
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 80,
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon: Icon(Icons.arrow_back,color: Colors.white,)),
        backgroundColor: Color(0xFF659F62), // Dark Green
        title: Text(
          "ADD NOTIFICATION",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500,color: Colors.white),
        ),

      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 50,
            ),
            // Input for Matter
            Text(
              "Enter Matter:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 10),
            TextField(
              controller: matterCtrl,
              decoration: InputDecoration(
                hintText: "Notification title",
                border: OutlineInputBorder(

                  borderRadius: BorderRadius.circular(10),

                ),
                filled: true,

                fillColor: Color(0xFFF0F8F5), // Light Green
              ),
            ),
            SizedBox(height: 20),

            // Input for Content
            Text(
              "Enter Content:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 10),
            TextField(
              controller: contentCtrl,
              maxLines: 6,
              decoration: InputDecoration(
                hintText: "Notification content",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                filled: true,
                fillColor: Color(0xFFF0F8F5), // Light Green
              ),
            ),
            SizedBox(height: 30),

            // Buttons for Notification Audience
            Text(
              "Send Notification To:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    clearFields(); // Logic for trainers can be added later
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF659F62), // Medium Green
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    "Trainers",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    clearFields(); // Logic for learners can be added later
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF659F62), // Medium Green
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    "Learners",
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
