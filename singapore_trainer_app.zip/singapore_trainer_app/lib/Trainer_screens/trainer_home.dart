import 'package:flashy_tab_bar2/flashy_tab_bar2.dart';
import 'package:flutter/material.dart';
import 'package:singapore_trainer_app/Trainer_screens/Details_page.dart';
import 'package:singapore_trainer_app/Trainer_screens/trainer_calender.dart';
import 'package:singapore_trainer_app/Trainer_screens/trainer_chat.dart';
import 'package:singapore_trainer_app/Trainer_screens/trainer_reviews.dart';
import 'package:singapore_trainer_app/Trainer_screens/Trainer_dashboard.dart';
import 'package:singapore_trainer_app/Trainer_screens/Trainer_profile.dart';
import 'Notification_trainer.dart';
import 'Trainer_screening.dart';
import 'batch_management.dart';
import 'trainer_plans_subcriptions.dart';

class Trainer_home extends StatefulWidget {
  const Trainer_home({super.key});

  @override
  State<Trainer_home> createState() => _Trainer_homeState();
}

class _Trainer_homeState extends State<Trainer_home> {
  int selectedIndex = 0;
  final PageController _pageController = PageController();

  final List<Widget> tabs = [
    DETAILS(),
    ChatingTrainer(),
    CalendarPage(),
    TrainerReviews(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F8F5),
      appBar: selectedIndex == 0
          ? AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        backgroundColor: const Color(0xFF659F62),
        toolbarHeight: 80,
        title: const Text(
          "TRAINER HOME",
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 18,
            color: Colors.white,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const notification_Trainer(),
                  ),
                );
              },
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              ),
            ),
          ),
        ],
      )
          : null, // Hide AppBar for other pages
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          children: [
            const SizedBox(height: 20),
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF659F62)),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TrainerProfile(),
                        ),
                      );
                    },
                    child: const CircleAvatar(
                      radius: 40,
                      backgroundImage: AssetImage('assets/profile.jpg'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "TRAINER MENU",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text("Dashboard"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TrainerDashboard(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.subscriptions_outlined),
              title: const Text("Plans"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SubscriptionPlansPage(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.batch_prediction),
              title: const Text("Batch Management"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BatchManagementPage(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.batch_prediction),
              title: const Text("Batch Management"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ScreeningTimePage(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        children: tabs,
      ),
      bottomNavigationBar: FlashyTabBar(
        selectedIndex: selectedIndex,
        backgroundColor: Colors.white,
        iconSize: 30,
        animationCurve: Curves.easeInOut,
        animationDuration: const Duration(milliseconds: 300),
        onItemSelected: (index) {
          setState(() {
            selectedIndex = index;
            _pageController.animateToPage(
              index,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          });
        },
        items: [
          FlashyTabBarItem(
            icon: const Icon(Icons.home),
            title: const Text('Home'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
          FlashyTabBarItem(
            icon: const Icon(Icons.chat),
            title: const Text('Chat'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
          FlashyTabBarItem(
            icon: const Icon(Icons.calendar_month),
            title: const Text('Calendar'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
          FlashyTabBarItem(
            icon: const Icon(Icons.reviews),
            title: const Text('Reviews'),
            activeColor: const Color(0xFF659F62),
            inactiveColor: Colors.black,
          ),
        ],
      ),
    );
  }
}
