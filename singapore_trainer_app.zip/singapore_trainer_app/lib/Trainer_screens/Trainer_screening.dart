import 'package:flutter/material.dart';

import '../utils/screening.dart';

class ScreeningTimePage extends StatefulWidget {
  @override
  _ScreeningTimePageState createState() => _ScreeningTimePageState();
}

class _ScreeningTimePageState extends State<ScreeningTimePage> {
  final List<Screening> screenings = [
    Screening(
        service: 'Swimming Class',
        date: DateTime.now().add(Duration(days: 2)),
        time: '2:00 PM',
        location: 'Training Pool A',
        isCompleted: false),
    Screening(
        service: 'Yoga Class',
        date: DateTime.now().subtract(Duration(days: 1)),
        time: '4:00 PM',
        location: 'Studio B',
        isCompleted: true),
  ];

  String filter = 'Upcoming';

  @override
  Widget build(BuildContext context) {
    List<Screening> filteredScreenings = screenings.where((screening) {
      if (filter == 'Upcoming') {
        return !screening!.isCompleted;
      } else if (filter == 'Completed') {
        return screening!.isCompleted;
      }
      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('My Screening Times'),
      ),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildFilterButton('Upcoming'),
              _buildFilterButton('Completed'),
              _buildFilterButton('All'),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredScreenings.length,
              itemBuilder: (context, index) {
                final screening = filteredScreenings[index];
                return Card(
                  child: ListTile(
                    title: Text(screening.service),
                    subtitle: Text(
                        '${screening.date.toLocal().toString().split(' ')[0]} at ${screening.time}\nLocation: ${screening.location}'),
                    trailing: screening.isCompleted
                        ? Icon(Icons.check, color: Colors.green)
                        : Icon(Icons.schedule, color: Colors.blue),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton(String title) {
    return ElevatedButton(
      onPressed: () {
        setState(() {
          filter = title;
        });
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: filter == title ? Colors.green : Colors.grey,
      ),
      child: Text(title),
    );
  }
}
